# ZONECRON GATEWAY --COMMANDES CONSOLE

Non sensible à la casse.

## INFO-DEBUG

| Exemple     | Description                                                   | Remarques             |
|-------------|---------------------------------------------------------------|-----------------------|
| HELP        | Affiche ces informations                                      |                       |
| VERSION     | Affiche la version de l'application                           |                       |
| LANGS       | Affiche les langues disponibles et actuelle en vert           |                       |
| LANG EN     | Change la langue à celle indiquée ( EN = anglais )            |                       |
| LICENSE     | Affiche la licence de copyright                               |                       |
| MANUAL      | Affiche les instructions de connexion à Flow Agility          |                       |
| INFO        |Affiche infos sur les connexions disponibles                   |                       |                 
| DEBUG       | Affiche l'état des messages de débogage actifs                |                       |
| DEBUG WSC   | Active/désactive les messages de débogage du client WebSocket |                       |
| CLEAR       | Efface la console                                             |                       |
| EXIT        | Termine l'exécution de l'application                          |                       |

## PORTS SÉRIE
| Exemple     | Description                                                   | Remarques             |
|-------------|---------------------------------------------------------------|-----------------------|
| SERIAL      | Affiche une liste des ports série disponibles                 |                       |
| SERIAL COM3 | Ferme le port série actuel et essaie d'ouvrir COM3            |                       |

## MINUTEUR
| Exemple     | Description                                                   | Remarques             |
|-------------|---------------------------------------------------------------|-----------------------|
| START       | Démarre le minuteur à 0                                       | seulement SANS dongle |
| START 3500  | Démarre le minuteur à 3500ms = 3,5s                           | seulement SANS dongle |
| STOP        | Arrête le minuteur en affichant le temps écoulé               | seulement SANS dongle |
| STOP 36748  | Arrête le minuteur en affichant 36748ms = 36,74s              | seulement SANS dongle |
| DATA 2:1:0  | Envoie 2 fautes, 1 refus et aucune élimination                |                       |
| RESET       | Réinitialise fautes, refus, élimin. à 0 et arrête le minuteur |                       |
| WALK        | Démarre une reconnaissance de parcours de 7 minutes           |                       |
| WALK 360    | Démarre une reconnaissance de parcours de 360s = 6 minutes    |                       |
| DOWN        | Démarre un compte à rebours de 15s pour que l'équipe commence | pas avec Flow Agility |
| DOWN 20     | Démarre un compte à rebours de 20s pour que l'équipe commence | pas avec Flow Agility |
| DOWN 0      | Désactive le mode compte à rebours pour le départ             |                       |
| FAIL        | Un capteur est en état d'alerte                               | réinitialise après 5s |
| OK          | Efface l'état FAIL = Tous les capteurs sont OK                |                       |
