# ZONECRON GATEWAY --COMANDI CONSOLE

Non sensibili al maiuscolo/minuscolo.

## INFO-DEBUG

| Esempio     | Descrizione                                                   | Note                  |
|-------------|---------------------------------------------------------------|-----------------------|
| HELP        | Mostra queste informazioni                                    |                       |
| VERSION     | Mostra la versione dell'applicazione                          |                       |
| LANGS       | Mostra le lingue disponibili e quella attuale in verde        |                       |
| LANG EN     | Cambia la lingua a quella indicata ( EN = inglese )           |                       |
| LICENSE     | Mostra la licenza di copyright                                |                       |
| MANUAL      | Mostra le istruzioni di connessione a Flow Agility            |                       |
| INFO        | Mostra informazioni su connessioni, reti e porte seriali      |                       |
| DEBUG       | Mostra lo stato dei messaggi di debug attivi                  |                       |
| DEBUG WSC   | Abilita/disabilita messaggi di debug client websocket         |                       |
| CLEAR       | Pulisce la console                                            |                       |
| EXIT        | Termina l'esecuzione dell'applicazione                        |                       |

## PORTE SERIE
| Esempio     | Descrizione                                                   | Note                  |
|-------------|---------------------------------------------------------------|-----------------------|
| SERIAL      | Mostra un elenco delle porte seriali disponibili              |                       |
| SERIAL COM3 | Chiude la porta seriale attuale e tenta di aprire COM3        |                       |

## TIMER
| Esempio     | Descrizione                                                   | Note                  |
|-------------|---------------------------------------------------------------|-----------------------|
| START       | Avvia il timer da 0                                           | solo SENZA dongle     |
| START 3500  | Avvia il timer a 3500ms = 3,5s                                | solo SENZA dongle     |
| STOP        | Ferma il timer mostrando il tempo trascorso                   | solo SENZA dongle     |
| STOP 36748  | Ferma il timer mostrando 36748ms = 36,74s                     | solo SENZA dongle     |
| DATA 2:1:0  | Invia 2 errori, 1 rifiuto e nessuna eliminazione              |                       |
| RESET       | Reimposta errori, rifiuti e elimi. a 0 e ferma il timer       |                       |
| WALK        | Avvia un riconoscimento del percorso di 7 minuti              |                       |
| WALK 360    | Avvia un riconoscimento del percorso di 360s = 6 minuti       |                       |
| DOWN        | Avvia conto alla rovescia di 15s per far partire il team      | non con Flow Agility  |
| DOWN 20     | Avvia conto alla rovescia di 20s per far partire il team      | non con Flow Agility  |
| DOWN 0      | Disattiva la modalità conto alla rovescia per l'inizio        |                       |
| FAIL        | Un fotocellula è in stato di allerta                          | auto-cancella in 5s.  |
| OK          | Cancella lo stato di FAIL = Tutte le fotocellule sono OK      |                       |
