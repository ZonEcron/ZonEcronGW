# ZONECRON GATEWAY --KONSOLEBEFEHLE

Nicht case-sensitiv.

## INFO-DEBUG

| Beispiel    | Beschreibung                                                  | Hinweise              |
|-------------|---------------------------------------------------------------|-----------------------|
| HELP        | Zeigt diese Informationen an                                  |                       |
| VERSION     | Zeigt die Version der Anwendung an                            |                       |
| LANGS       | Zeigt verfügbare Sprachen an und die aktuelle in grün         |                       |
| LANG EN     | Ändert die Sprache auf die angegebene ( EN=Englisch )         |                       |
| LICENSE     | Zeigt die Urheberrechtslizenz an                              |                       |
| MANUAL      | Zeigt Anweisungen zur Verbindung mit Flow Agility             |                       |
| INFO        | Zeigt verfügbare Verbindungen an                              |                       |
| DEBUG       | Zeigt den Status der aktiven Debug-Nachrichten an             |                       |
| DEBUG WSC   | Aktiviert/deaktiviert Debug für den Websocket-Client          |                       |
| CLEAR       | Löscht die Konsole                                            |                       |
| EXIT        | Beendet die Ausführung der Anwendung                          |                       |

## SERIELLE PORTS
| Beispiel    | Beschreibung                                                  | Hinweise              |
|-------------|---------------------------------------------------------------|-----------------------|
| SERIAL      | Zeigt eine Liste der verfügbaren seriellen Ports an           |                       |
| SERIAL COM3 | Schließt den akt. seriellen und versucht, COM3 zu öffnen      |                       |

## TIMER
| Beispiel    | Beschreibung                                                  | Hinweise              |
|-------------|---------------------------------------------------------------|-----------------------|
| START       | Startet den Timer von 0                                       | nur OHNE Dongle       |
| START 3500  | Startet den Timer bei 3500ms = 3,5s                           | nur OHNE Dongle       |
| STOP        | Stoppt den Timer und zeigt die verstrichene Zeit an           | nur OHNE Dongle       |
| STOP 36748  | Stoppt den Timer und zeigt 36748ms = 36,74s an                | nur OHNE Dongle       |
| DATA 2:1:0  | Sendet 2 Fehler, 1 Ablehnung und keine Streichung             |                       |
| RESET       | Setzt Flt., Ref. und Gel. auf 0 und stoppt den Timer.         |                       |
| WALK        | Startet einen 7-minütigen Kurslauf                            |                       |
| WALK 360    | Startet einen 360s = 6-minütigen Kurslauf                     |                       |
| DOWN        | Startet einen 15s CD für das Team zum Kursbeginn              | nicht Flow Agility    |
| DOWN 20     | Startet einen 20s CD für das Team zum Kursbeginn              | nicht Flow Agility    |
| DOWN 0      | Deaktiviert den CD-Modus für den Start                        |                       |
| FAIL        | Eine Fotokollisator befindet sich im Alarmzustand             | nach 5s zurückgesetzt |
| OK          | Löscht den FAIL-Zustand = Alle Fotokollisatoren sind OK       |                       |
