# ZONECRON GATEWAY --PŘÍKAZY K TERMINÁLU

Nezohledňuje velikost písmen.

## INFO-DEBUG

| Příklad     | Popis                                                         | Poznámky              |
|-------------|---------------------------------------------------------------|-----------------------|
| HELP        | Zobrazuje tyto informace                                      |                       |
| VERSION     | Zobrazuje verzi aplikace                                      |                       |
| LANGS       | Zobrazuje dostupné jazyky a aktuální v zelené                 |                       |
| LANG EN     | Změní jazyk na uvedený ( EN = angličtina )                    |                       |
| LICENSE     | Zobrazuje licenci na autorská práva                           |                       |
| MANUAL      | Zobrazuje pokyny pro připojení k Flow Agility                 |                       |
| INFO        | Zobrazuje informace o dostupných připojeních                  |                       |
| DEBUG       | Zobrazuje stav aktivních ladicích zpráv                       |                       |
| DEBUG WSC   | Aktivuje/deaktivuje ladicí zprávy websocket klienta           |                       |
| CLEAR       | Vymaže terminál                                               |                       |
| EXIT        | Ukončí provádění aplikace                                     |                       |
																	          
## SÉRIOVÉ PORTY                                                              
| Příklad     | Popis                                                         | Poznámky              |
|-------------|---------------------------------------------------------------|-----------------------|
| SERIAL      | Zobrazuje seznam dostupných sériových portů                   |                       |
| SERIAL COM3 | Zavře aktuální sériový port a pokusí se otevřít COM3          |                       |
																	          
## CHRONOMETR                                                                 
| Příklad     | Popis                                                         | Poznámky              |
|-------------|---------------------------------------------------------------|-----------------------|
| START       | Spustí chronometr od 0                                        | pouze BEZ donglu      |
| START 3500  | Spustí chronometr na 3500ms = 3,5s                            | pouze BEZ donglu      |
| STOP        | Zastaví chronometr a zobrazí uplynulý čas                     | pouze BEZ donglu      |
| STOP 36748  | Zastaví chronometr a zobrazí 36748ms = 36,74s                 | pouze BEZ donglu      |
| DATA 2:1:0  | Odesílá 2 chyby, 1 odmítnutí a žádné odstranění               |                       |
| RESET       | Resetuje chyby, odm. a odstr. a zastaví chronometr            |                       |
| WALK        | Zahájí 7 minutový kurs                                        |                       |
| WALK 360    | Zahájí 360s = 6 minutový kurs                                 |                       |
| DOWN        | Spustí 15s odpočet pro tým, aby začal kurz                    | ne s Flow Agility     |
| DOWN 20     | Spustí 20s odpočet pro tým, aby začal kurz                    | ne s Flow Agility     |
| DOWN 0      | Deaktivuje CD režim pro začátek                               |                       |
| FAIL        | Některá fotobuňka je v alarmovém stavu                        | se auto-borí za 5s.   |
| OK          | Vymaže stav FAIL = Všechny fotobuňky jsou OK                  |                       |
