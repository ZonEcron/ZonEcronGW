# ZONECRON GATEWAY --CONSOLE COMMANDS

Not case-sensitive.

## INFO-DEBUG

| Example     | Description                                                   | Notes                 |
|-------------|---------------------------------------------------------------|-----------------------|
| HELP        | Displays this information                                     |                       |
| VERSION     | Displays the application version                              |                       |
| LANGS       | Displays available languages and selected in green            |                       |
| LANG EN     | Changes language to indicated ( EN = english )                |                       |
| LICENSE     | Displays the copyright license                                |                       |
| MANUAL      | Displays connection instructions to Flow Agility              |                       |
| INFO        | Displays connections, networks, and serial ports info         |                       |
| DEBUG       | Displays the status of active debug messages                  |                       |
| DEBUG WSC   | Enables/disables websocket client debug messages              |                       |
| CLEAR       | Clears the console                                            |                       |
| EXIT        | Terminates the application execution                          |                       |

## SERIAL PORTS
| Example     | Description                                                   | Notes                 |
|-------------|---------------------------------------------------------------|-----------------------|
| SERIAL      | Displays a list of available serial ports                     |                       |
| SERIAL COM3 | Closes the current serial port and tries to open COM3         |                       |

## TIMER
| Example     | Description                                                   | Notes                 |
|-------------|---------------------------------------------------------------|-----------------------|
| START       | Starts the timer from 0                                       | only WITHOUT dongle   |
| START 3500  | Starts the timer at 3500ms. = 3.5s.                           | only WITHOUT dongle   |
| STOP        | Stops the timer showing the elapsed time                      | only WITHOUT dongle   |
| STOP 36748  | Stops the timer showing 36748ms. = 36.74s.                    | only WITHOUT dongle   |
| DATA 2:1:0  | Sends 2 faults, 1 refusal, and no elimination                 |                       |
| RESET       | Resets faults, refusals, and elimin. and stops timer          |                       |
| WALK        | Starts a 7-minute course walk                                 |                       |
| WALK 360    | Starts a 360s. = 6-minute course walk                         |                       |
| DOWN        | Starts a 15s CD for the team to start the course              | no with FlowAgility   |
| DOWN 20     | Starts a 20s CD for the team to start the course              | no with FlowAgility   |
| DOWN 0      | Disables the CD mode for start                                |                       |
| FAIL        | A photocell is in an alarm state                              | auto-resets after 5s. |
| OK          | Clears the FAIL state = All photocells are OK                 |                       |
