# ZONECRON GATEWAY --COMANDOS DO CONSOLE

Não diferencia maiúsculas e minúsculas.

## INFO-DEBUG

| Exemplo     | Descrição                                                     | Notas                 |
|-------------|---------------------------------------------------------------|-----------------------|
| HELP        | Mostra esta informação                                        |                       |
| VERSION     | Mostra a versão da aplicação                                  |                       |
| LANGS       | Mostra os idiomas disponíveis e o atual em verde              |                       |
| LANG EN     | Altera o idioma para o indicado ( EN = inglês )               |                       |
| LICENSE     | Mostra a licença de copyright                                 |                       |
| MANUAL      | Mostra instruções de conexão ao Flow Agility                  |                       |
| INFO        | Mostra informações de conexões, redes e portas série          |                       |
| DEBUG       | Mostra o status das mensagens de depuração ativas             |                       |
| DEBUG WSC   | Ativa/desativa mens. depuração do cliente websocket           |                       |
| CLEAR       | Limpa o console                                               |                       |
| EXIT        | Termina a execução da aplicação                               |                       |

## PORTAS SERIAIS
| Exemplo     | Descrição                                                     | Notas                 |
|-------------|---------------------------------------------------------------|-----------------------|
| SERIAL      | Mostra uma lista das portas seriais disponíveis               |                       |
| SERIAL COM3 | Fecha a porta serial atual e tenta abrir a COM3               |                       |

## CRONÔMETRO
| Exemplo     | Descrição                                                     | Notas                 |
|-------------|---------------------------------------------------------------|-----------------------|
| START       | Inicia o cronômetro a partir de 0                             | somente SEM dongle    |
| START 3500  | Inicia o cronômetro a partir de 3500ms = 3,5s                 | somente SEM dongle    |
| STOP        | Para o cronômetro mostrando o tempo decorrido                 | somente SEM dongle    |
| STOP 36748  | Para o cronômetro mostrando 36748ms = 36,74s                  | somente SEM dongle    |
| DATA 2:1:0  | Envia 2 faltas, 1 recusa e nenhum eliminado                   |                       |
| RESET       | Reseta faltas, recusas e eliminado e para o cronômetro        |                       |
| WALK        | Inicia um reconhecimento de pista de 7 minutos                |                       |
| WALK 360    | Inicia um reconhecimento de pista de 360s = 6 minutos         |                       |
| DOWN        | Inicia uma contagem de 15s para o guia iniciar a pista        | não com Flow Agility  |
| DOWN 20     | Inicia uma contagem de 20s para o guia iniciar a pista        | não com Flow Agility  |
| DOWN 0      | Desativa o modo de contagem para início                       |                       |
| FAIL        | Uma fotocélula está em estado de alarme                       | se auto-borra em 5s   |
| OK          | Limpa o estado de FAIL = Todas as fotocélulas estão OK        |                       |
