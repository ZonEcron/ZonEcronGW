fetch('./menu.html')
    .then(response => response.text())  // Convertir a texto (html)
    .then(data => {
        // Crear un parser HTML temporal para poder seleccionar parte del HTML
        const parser = new DOMParser();
        const doc = parser.parseFromString(data, 'text/html');

        // Insertamos el contenido seleccionado en la página actual
        document.getElementById('menu').innerHTML = doc.getElementById('menudinamico').innerHTML;
        dinamizarMenu();
    })
    .catch(error => console.error('Error loading menu.html:', error));

function dinamizarMenu() {
    // Mostra y ocultar los menus correspondientes y añadir los escuchadores

    const thisUrl = window.location.pathname;
    const thisFilename = thisUrl.substring(thisUrl.lastIndexOf('/') + 1);

    // listas de elementos del menu 
    const collap = document.getElementsByClassName("collapse");
    const subOpt = document.getElementsByName("subOpt");

    // ocultar todos los submenus
    for (let j = 0; j < subOpt.length; j++) {
        subOpt[j].style.display = "none";
    }

    // mostrar el submenu que corresponde a la pagina actual
    for (let j = 0; j < subOpt.length; j++) {

        if (thisFilename === "index.html" && subOpt[j].className === "inforSub") { subOpt[j].style.display = "block"; }
        if (thisFilename === "sistema.html" && subOpt[j].className === "inforSub") { subOpt[j].style.display = "block"; }
        if (thisFilename === "tiempos.html" && subOpt[j].className === "inforSub") { subOpt[j].style.display = "block"; }

        if (thisFilename === "mochila.html" && subOpt[j].className === "conecSub") { subOpt[j].style.display = "block"; }
        if (thisFilename === "flowAgility.html" && subOpt[j].className === "conecSub") { subOpt[j].style.display = "block"; }

        /* estos nunca empezaran abiertos porque en sus paginas no hay menu */
        /*
        if (thisFilename === "mandoCrono.html"   && subOpt[j].className === "mandoSub") { subOpt[j].style.display = "block"; }
        if (thisFilename === "mandoTurno.html"   && subOpt[j].className === "mandoSub") { subOpt[j].style.display = "block"; }
        if (thisFilename === "monitorCrono.html" && subOpt[j].className === "pantaSub") { subOpt[j].style.display = "block"; }
        if (thisFilename === "monitorTurno.html" && subOpt[j].className === "pantaSub") { subOpt[j].style.display = "block"; }
        if (thisFilename === "streamCrono.html"  && subOpt[j].className === "pantaSub") { subOpt[j].style.display = "block"; }
        if (thisFilename === "streamInfo.html"   && subOpt[j].className === "pantaSub") { subOpt[j].style.display = "block"; }
        */
    }

    /* añadir escuchadores para contraer y expandir seciones del menu */
    for (let i = 0; i < collap.length; i++) {
        collap[i].addEventListener("click", function () {
            for (let j = 0; j < subOpt.length; j++) {
                if (subOpt[j].className === this.id) {
                    if (subOpt[j].style.display === "block") {
                        subOpt[j].style.display = "none";
                    } else {
                        subOpt[j].style.display = "block";
                    }
                } else {
                    // contraer menu cuando se clicka en otro diferente
                    // subOpt[j].style.display = "none";
                }
            }
        });
    }
}
