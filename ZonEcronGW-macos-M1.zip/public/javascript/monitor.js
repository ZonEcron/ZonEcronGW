var inicio = 0;
var tiem = 0;
var modo = "p";
var intervalo;
var retNoPing = 60000;
var noPingTimer = setTimeout(noPing, retNoPing);
var connection = new WebSocket('ws://' + location.host + '/');

const turno = document.getElementById("turno");
const talla = document.getElementById("talla");
const errorCel = document.getElementById("errorCel");
const tiempo = document.getElementById("tiempo");
const colortexto = document.getElementById("colortexto");
const colorfondo = document.getElementById("colorfondo");
const recofaltuse = document.getElementById("recofaltuse");

connection.onopen = function () { connection.send("d0"); connection.send("050"); };
connection.onmessage = function (mensaje) {
    const dato = mensaje.data;
    console.log(dato);
    if (dato === '__ping__') {
        clearTimeout(noPingTimer);
        noPingTimer = setTimeout(noPing, retNoPing);
    } else if (isNaN(dato.substring(0, 1)) && dato.length === 11) {
        modo = dato[0];
        const vFal = dato[1] * 1;
        const vReh = dato[2] * 1;
        const vEli = dato[3] * 1;
        textofaltuse(vFal, vReh, vEli);
        tiem = parseInt(dato.substring(4));
        clearInterval(intervalo);
        if (modo === "i") {
            inicio = new Date().getTime() - tiem;
            reloj(tiem, 0);
            intervalo = setInterval(function () { crono() }, 100);
        }
        if (modo === "p") {
            inicio = new Date().getTime() - tiem;
            reloj(tiem, 1);
        }
        if (modo === "g" || modo === "o" || modo === "s" || modo === "q") {
            inicio = new Date().getTime() + tiem;
            reloj(tiem, 0);
            if (modo === "g" || modo === "s") {
                intervalo = setInterval(function () { atras() }, 100);
            }
        }
    } else {
        const datos = dato.split(';');
        if (datos[0] === "022") {
            if (errorCel) {
                console.log(dato);
                if (datos[5] > 0) {
                    errorCel.style.color = "red";
                    errorCel.innerHTML = "{{REM_cells_unaligned}}";
                } else if (datos[1] === 0 || datos[2] === 0 || datos[3] === 0 || datos[4] === 0) {
                    errorCel.style.color = "red";
                    errorCel.innerHTML = "{{REM_cells_battery_empty}}";
                } else if (datos[1] <= 20 || datos[2] <= 20 || datos[3] <= 20 || datos[4] <= 20) {
                    errorCel.style.color = "red";
                    errorCel.innerHTML = "{{REM_cells_battery_critical}}";
                } else if (datos[1] <= 40 || datos[2] <= 40 || datos[3] <= 40 || datos[4] <= 40) {
                    errorCel.style.color = "orange";
                    errorCel.innerHTML = "{{REM_cells_battery_low}}";
                } else {
                    errorCel.style.color = "green";
                    errorCel.innerHTML = "{{REM_cells_ok}}";
                }
            }
        }
        if (datos[0] === "050") {
            if (turno) {
                console.log(dato);
                turno.innerHTML = "<b>" + datos[1] + "</b>";
                if (isNaN(datos[2])) datos[2] = 0;
                if (datos[2] * 1 != 0) {
                    talla.innerHTML = "<b>{{TUR_height}} " + datos[2] + "</b>";
                } else {
                    talla.innerHTML = "<b></b>";
                }
            }
        }
    }
};

function crono() {
    reloj(new Date().getTime() - inicio, 0);
}

function atras() {
    let actual = inicio - (new Date().getTime());
    if (actual < 0) {
        clearInterval(intervalo);
        reloj(0, 0);
        if (modo === 'g') modo = 'p';
        if (modo === 's') {
            modo = 'i';
            intervalo = setInterval(function () { crono() }, 100);
        }
        textofaltuse(0, 0, 0);
    } else {
        reloj(actual, 0);
    }
}

function reloj(elapsed, muestraCentesimas) {
    if (tiempo) {
        let valor = "00.00";
        if (elapsed > 0) {
            let enteros = Math.floor(elapsed / 1000);
            let decimal = ("000" + elapsed % 1000).slice(-3);
            let minutos = Math.floor(enteros / 60);
            let segundos = enteros % 60;
            if (minutos < 10) minutos = "0" + minutos;
            if (segundos < 10) segundos = "0" + segundos;
            if ((modo === 'o' || modo === 'g')) {
                valor = minutos + ":" + segundos;
            } else {
                if (muestraCentesimas) {
                    decimal = decimal.substring(0, 2);
                } else {
                    decimal = decimal.substring(0, 1) + "0";
                }
                valor = (enteros < 10 )
                    ? ("0" + enteros).slice(-2) + "." + decimal
                    : enteros + "." + decimal;
            }
        }
        tiempo.innerHTML = valor;
    }
}

function changeColors() {
    document.body.style.setProperty('--sTexto', colortexto.value);
    document.body.style.setProperty('--sFondo', colorfondo.value);
}

function textofaltuse(falV, rehV, eliV) {
    if (recofaltuse) {
        recofaltuse.innerHTML = (modo === 'g' || modo === 'o')
            ? "{{REM_course_walk}}"
            : eliV
                ? "{{REM_table_eliminated}}"
                : `{{REM_faults_shortened}}:${falV} - {{REM_refusals_shortened}}:${rehV}`;
    }
}

function noPing() {
    location.reload();
}