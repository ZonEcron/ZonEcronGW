var docWSSurl = document.getElementById('WSSurl');
var docmacAdd = document.getElementById('macAdd');
var docWSStatus = document.getElementById('WSStatus');
var docssl = document.getElementById('ssl');
var docBConectar = document.getElementById('bConectar');
var docBDesConectar = document.getElementById('bDesConectar');

var retNoPing = 60000;
var noPingTimer = setTimeout(noPing, retNoPing);

let connection = new WebSocket('ws://' + location.host + '/');
connection.onopen = function () { connection.send("090"); };
connection.onmessage = function (mensaje) {
	if (mensaje.data == '__ping__') {
		clearTimeout(noPingTimer);
		noPingTimer = setTimeout(noPing, retNoPing);
		return;
	}
	console.log(mensaje.data);
	var datos = mensaje.data.split(";");
	if (datos[0] == "090") {
		docWSSurl.value = datos[1];
		docmacAdd.innerHTML = `<b>${datos[2]}</b>`;
        if (datos[3] === '1') {
            if (datos[4] === '0') {
                docBConectar.disabled = false;
                docWSStatus.innerHTML = "{{FA_status_url_invalid}}";
                docWSStatus.style.color = "#F00";
            } else if (datos[4] === '1') {
                docBDesConectar.disabled = false;
                docWSStatus.innerHTML = "{{FA_status_connected}}";
                docWSStatus.style.color = "#080";
            }
        } else if (datos[3] === '0') {
            if (datos[4] === '0') {
                docBConectar.disabled = false;
                docWSStatus.innerHTML = "{{FA_status_disconnected}}";
                docWSStatus.style.color = "#F00";
            } else if (datos[4] === '1') {
                docBDesConectar.disabled = false;
                docWSStatus.innerHTML = "S";
                docWSStatus.style.color = "#FA0";
            }
        }
		docssl.selectedIndex = datos[5] * 1;
	}
}

function connectWSS() {
	docBConectar.disabled = true;
	const url = docWSSurl.value.trim();
	const ssl = docssl.selectedIndex;
	connection.send(`190;${url};1;${ssl}`);
}
function disConnectWSS() {
	docBDesConectar.disabled = true;
	const url = docWSSurl.value.trim();
	const ssl = docssl.selectedIndex;
	connection.send(`190;${url};0;${ssl}`);
}
function noPing() {
	location.reload();
}
