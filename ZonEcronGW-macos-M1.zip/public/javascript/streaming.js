/*----- HIDE CURSOR -----*/
const hideCursorDly = 5000;
let hideCursorTimer = setTimeout(hideCursor, hideCursorDly);

/* ----- TIMER WEBSOCKET AND HEARTBEAT ----- */
var connectionT = { readyState: WebSocket.CLOSED };
var timerPingTimeout;
const timerPingDelay = 55000;
var inicio = new Date().getTime();
var tiem = 0;
var modo = "p";
var falt = 0;
var rehu = 0;
var elim = 0;
var intervalo;
var timerReconnTimeout;
var timerReconnCountD;
var timerReconnTimeLeft = 5;

/* ----- GENERAL WINDOW ----- */
var defSettings = true;
var imageLoaded = false;

/* ----- INFORMATION DISPLAYED ----- */
const time = document.getElementById("time");
const speed = document.getElementById("speed");
const faults = document.getElementById("faults");
const refusals = document.getElementById("refusals");
const eliminated = document.getElementById("eliminated");

/* ----- SELECTORES POR CLASE ----- */
const dragable = document.getElementsByClassName("dragable");
const animable = document.getElementsByClassName("animable");
const windowBG = document.getElementsByClassName("windowBG");
const windowTitle = document.getElementsByClassName("windowTitle");

/* ----- MODAL WINDOW ----- */
const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modalTitle');
const fontInput = document.getElementById("fontInput");
const sizeInput = document.getElementById("sizeInput");
const textColorInput = document.getElementById("textColorInput");
const itemBGcolorInput = document.getElementById("itemBGcolorInput");
const hiddenCheck = document.getElementById("hiddenCheck");
const itemHeight = document.getElementById("itemHeight");
const itemWidth = document.getElementById("itemWidth");
const posXInput = document.getElementById("posXInput");
const posYInput = document.getElementById("posYInput");
const posZInput = document.getElementById("posZInput");
const text1 = document.getElementById("text1");
const text2 = document.getElementById("text2");
const textsTitle = document.getElementById("textsTitle");
const labelText1 = document.getElementById("labelText1");
const labelText2 = document.getElementById("labelText2");

/* ----- GENERAL WINDOW ----- */
const hideMe = document.getElementById("hideMe");
const general = document.getElementById("general");
const croma = document.getElementById("croma");
const cromaBGcolorInput = document.getElementById("cromaBGcolorInput");
const editButton = document.getElementById("editButton");
const impExButton = document.getElementById("impExButton");
const overlay = document.getElementById('overlay');
const imageFile = document.getElementById('imageFile');
const imageName = document.getElementById('imageName');
const imageStatus = document.getElementById('imageStatus');
const loadImgButton = document.getElementById('loadImgButton');
const maxSpeedInput = document.getElementById("maxSpeedInput");
const lengthInput = document.getElementById("lengthInput");

/* ----- POPUP HELP WINDOW -----*/
let closeWarningTimeout;
let infoTimeout;
const infoDelay = 1000;
const vInfo = document.getElementById("vInfo");

/* ----- UNDO QUEUE -----*/
var undoArray = [];
var undoPointer = 0;

/* ----- INITIALIZATION FUNCTIONS ----- */
(function () {

	setTimeout(() => { hideMe.style.display = "none"; }, 10000);
	defaultTextsAndFlags();
	importSettings(readLocal("streamSettings"));
	configDragables();
	eventTriggers();
	populateUndoArray(readAllSettings());
	websocTimer();

})();
function defaultTextsAndFlags() {

	/* ----- DEFAULT BEFORE AND AFTER TEXTS OF SOME ELEMENTS -----*/
	faults.text1 = "F";
	refusals.text1 = "R";
	eliminated.text1 = eliminated.innerText;

	/* ----- FLAGS -----*/
	general.editing = false;
	general.showing = false;
	modal.showing = false;

}
function configDragables() {
	/* ----- CONFIG DRAGABLE ITEMS ----- */
	for (let item of dragable) {
		item.text1 = item.text1 || "";
		item.text2 = item.text2 || "";
		item.text1old = item.text1;
		item.text2old = item.text2;
		makeDragable(item);
		item.addEventListener("dblclick", () => {

			if (general.editing && !general.showing && !modal.showing) {

				modalTitle.innerHTML = "Properties " + item.id;

				textsTitle.innerHTML = "Before and After Texts";
				labelText1.innerHTML = "Before";
				labelText2.innerHTML = "After";

				labelText2.style.visibility = "visible";
				text2.style.visibility = "visible";

				if (item.id === "eliminated") {
					textsTitle.innerHTML = "Text for";
					labelText1.innerHTML = "Eliminated";
					text2.style.visibility = "hidden"
					labelText2.style.visibility = "hidden";
				}

				// Tabla, fila o titulos de columna
				if (item.classList.contains('tableCont') || item.classList.contains('tableRow') || item.classList.contains('tableCoTi')) {
					textsTitle.innerHTML = "Text for";
					labelText1.innerHTML = "Table title";
					text2.style.visibility = "hidden"
					labelText2.style.visibility = "hidden";
				}

				dragProperties(item);
				modal.elemento = item;

				fontInput.value = item.fontFamily;
				sizeInput.value = item.fontSize;
				textColorInput.value = item.color;
				itemBGcolorInput.value = item.bgColor;
				hiddenCheck.checked = item.hiddenCheck;

				itemHeight.value = item.height;
				itemWidth.value = item.width;

				posXInput.value = item.posX;
				posYInput.value = item.posY;
				posZInput.value = item.posZ;

				text1.value = item.text1;
				text2.value = item.text2;

				modal.style.display = "block";
				modal.showing = true;

			}
		});

	}
	/* ----- CONFIG WINDOWS ----- */
	for (let item of windowBG) {
		makeDragable(item);
	}
	for (let item of windowTitle) {
		makeDragable(item);
		item.isDragable = false;
	}
}
function eventTriggers() {
	/* ----- CURSOR HIDE/SHOW ----- */
	window.addEventListener('mousemove', showCursor);
	window.addEventListener('keydown', showCursor);
	/* ----- BROWSERS SYNC -----*/
	window.addEventListener('storage', () => {
		const storedSettings = readLocal("streamSettings");
		if (storedSettings) {
			importSettings(storedSettings);
		} else {
			location.reload();
		}
	});
	/* ----- GENERAL AND MODAL WINDOWS -----*/
	window.onclick = function (event) {
		if (modal.showing && event.target != modal && !modal.contains(event.target)) {
			vInfo.style.display = "block";
			vInfo.innerHTML = "Close properties window to drag & drop items";
			clearTimeout(closeWarningTimeout);
			closeWarningTimeout = setTimeout(oInfo, 1500);
		}
		if (general.showing && event.target != general && !general.contains(event.target)) {
			vInfo.style.display = "block";
			vInfo.innerHTML = "Close properties window to drag & drop items";
			clearTimeout(closeWarningTimeout);
			closeWarningTimeout = setTimeout(oInfo, 1500);
		}
	}
	window.ondblclick = event => {
		hideMe.style.display = "none";
		window.getSelection()?.removeAllRanges();
		if ((event.target == croma || event.target == overlay) && !modal.showing) {

			const compStyle = window.getComputedStyle(croma);
			cromaBGcolorInput.value = rgbaToHex(compStyle.getPropertyValue("background-color"))

			general.bgColor = cromaBGcolorInput.value;
			general.imageName = imageName.value;

			general.style.display = "block";
			general.showing = true;

		}
	}
	/* ----- POPUP INFO -----*/
	document.addEventListener("mousemove", event => {
		vInfo.style.left = (event.pageX + 50) + "px";
		vInfo.style.top = event.pageY + "px";
		clearTimeout(infoTimeout);
		oInfo();
		const element = document.elementFromPoint(event.pageX, event.pageY);
		if (element) { infoTimeout = setTimeout(() => { mInfo(element.id) }, infoDelay); }
	});
	document.addEventListener("mousedown", () => {
		clearTimeout(infoTimeout);
		oInfo();
	});
	/* ----- UNDO / REDO -----*/
	document.addEventListener('keydown', event => {
		if (general.editing) {
			if (event.ctrlKey && event.key === 'z') {
				undoEdit();
			}
			if (event.shiftKey && event.ctrlKey && event.key === 'z') {
				redoEdit();
			}
			if (event.ctrlKey && event.key === 'y') {
				redoEdit();
			}
		}
	});
	/* ----- IMAGE FILE SELECT -----*/
	imageFile.addEventListener('change', event => {
		if (event.target.files[0]) {
			const reader = new FileReader();
			reader.onload = e => overlay.src = e.target.result;
			reader.readAsDataURL(event.target.files[0]);
		}
	});
}

/* ----- LOCAL STORAGE FUNCTIONS ----- */
function importSettings(mySettings) {

	if (mySettings) {

		hideMe.style.display = "none";
		toggleImpExp();

		croma.style.backgroundColor = mySettings.visual.bgColor || "#000000";
		lengthInput.value = mySettings.visual.length || 220;
		maxSpeedInput.value = mySettings.visual.maxSpeed || 9.9;

		if (isValidBase64(mySettings.visual.imgData)) {
			overlay.src = "data:image/png;base64," + mySettings.visual.imgData;
			imageName.value = mySettings.visual.imgName || "";
			imageLoaded = true;
			imageStatus.innerHTML = "Loaded";
			imageStatus.style.color = "green";
			loadImgButton.innerHTML = "Delete";
		}

		for (let item of dragable) {

			item.style.fontFamily = mySettings[item.id] && mySettings[item.id].fontFamily || item.style.fontFamily;
			item.style.fontSize = mySettings[item.id] && mySettings[item.id].fontSize * 1 + 'px' || item.style.fontSize;
			item.style.color = mySettings[item.id] && mySettings[item.id].color || item.style.color;
			item.style.backgroundColor = mySettings[item.id] && mySettings[item.id].bgColor || item.style.backgroundColor;
			item.hidden = mySettings[item.id] && mySettings[item.id].hidden || item.hidden;

			item.style.height = mySettings[item.id] && mySettings[item.id].height * 1 + 'px' || item.style.height;
			item.style.width = mySettings[item.id] && mySettings[item.id].width * 1 + 'px' || item.style.width;
			item.style.left = mySettings[item.id] && mySettings[item.id].posX * 1 + 'px' || item.style.left;
			item.style.top = mySettings[item.id] && mySettings[item.id].posY * 1 + 'px' || item.style.top;
			item.style.zIndex = mySettings[item.id] && mySettings[item.id].posZ * 1 || item.style.zIndex;

			item.fontFamily = mySettings[item.id] && mySettings[item.id].fontFamily || item.fontFamily;
			item.fontSize = mySettings[item.id] && mySettings[item.id].fontSize || item.fontSize;
			item.color = mySettings[item.id] && mySettings[item.id].color || item.color;
			item.bgColor = mySettings[item.id] && mySettings[item.id].bgColor || item.bgColor;
			item.hiddenCheck = mySettings[item.id] && mySettings[item.id].hidden || item.hiddenCheck;

			item.height = mySettings[item.id] && mySettings[item.id].height || item.height;
			item.width = mySettings[item.id] && mySettings[item.id].width || item.width;
			item.posX = mySettings[item.id] && mySettings[item.id].posX || item.posX;
			item.posY = mySettings[item.id] && mySettings[item.id].posY || item.posY;
			item.posZ = mySettings[item.id] && mySettings[item.id].posZ || item.posZ;

			item.text1 = mySettings[item.id] && mySettings[item.id].text1 || "";
			item.text2 = mySettings[item.id] && mySettings[item.id].text2 || "";

		}

	}
}
function storeLocal(keyName, mySettings) {
	const jsonString = JSON.stringify(mySettings);
	localStorage.setItem(keyName, jsonString);
}
function readLocal(keyName) {
	try {
		const jsonString = localStorage.getItem(keyName);
		const mySettings = JSON.parse(jsonString);
		return mySettings;
	} catch (error) {
		return null;
	}
}
function getBase64Image(img) {
	var canvas = document.createElement("canvas");
	canvas.width = img.width;
	canvas.height = img.height;

	var ctx = canvas.getContext("2d");
	ctx.drawImage(img, 0, 0);

	var dataURL = canvas.toDataURL("image/png");

	return dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
}
function isValidBase64(str) {
	try {
		return btoa(atob(str)) === str;
	} catch (e) {
		return false;
	}
}

/* ----- WEBSOCKET TIMER FUNCTIONS ----- */
function websocTimer() {

	connectionT = new WebSocket('ws://' + location.host);

	connectionT.onopen = () => {
		connectionT.send("d0");
	};

	connectionT.onmessage = (message) => {

		const data = message.data;

		if (data == '__ping__') {
			clearTimeout(timerPingTimeout);
			timerPingTimeout = setTimeout(noTimerPing, timerPingDelay);
			return;
		}

		const format = /^[A-Za-z]\d{10}$/;

		if (format.test(data)) {

			console.log(data);
			modo = data[0];
			falt = parseInt(data[1]);
			rehu = parseInt(data[2]);
			elim = parseInt(data[3]);

			tiem = parseInt(data.substring(4));
			clearInterval(intervalo);

			if (modo === 'i') {
				inicio = new Date().getTime() - tiem;
				clock(tiem, 0);
				setSpeed(tiem);
				intervalo = setInterval(() => { crono() }, 100);
			} else if (modo === 'p') {
				inicio = new Date().getTime() - tiem;
				clock(tiem, 1);
				setSpeed(tiem);
			} else if (modo === "g" || modo === "o" || modo === "s" || modo === "q") {
				inicio = new Date().getTime() + tiem;
				clock(tiem, 0);
				if (modo === "g" || modo === "s") {
					intervalo = setInterval(function () { atras() }, 100);
				}
			}

			faults.innerHTML = `${faults.text1}${falt}${faults.text2}`;
			refusals.innerHTML = `${refusals.text1}${rehu}${refusals.text2}`;

			if (modo === "g" || modo === "o") {
				faults.style.visibility     = "hidden";
				refusals.style.visibility   = "hidden";
				eliminated.style.visibility = "hidden";
				speed.style.visibility      = "hidden";

			} else {
				faults.style.visibility     = elim === 0 ? "visible" : "hidden";
				refusals.style.visibility   = elim === 0 ? "visible" : "hidden";
				eliminated.style.visibility = elim !== 0 ? "visible" : "hidden";
				speed.style.visibility = "visible";

			}
		}
	}

	connectionT.onerror = () => {
		noTimerPing();
	}

	connectionT.onclose = () => {
		noTimerPing();
	}
}
function noTimerPing() {
	location.reload();
}
function crono() {
	let tiempoActual = new Date().getTime() - inicio;
	clock(tiempoActual, 0);
	setSpeed(tiempoActual);
}
function atras() {
	let actual = inicio - (new Date().getTime());
	if (actual < 0) {
		clearInterval(intervalo);
		clock(0, 0);
		if (modo === 'g') modo = 'p';
		if (modo === 's') {
			modo = 'i';
			intervalo = setInterval(function () { crono() }, 100);
		}
		// textofaltuse(0, 0, 0);
	} else {
		clock(actual, 0);
	}
}
function clock(muestraTiempo, muestraCentesimas) {
	let valor = "0.00";
	if (muestraTiempo > 0) {
		let enteros = Math.floor(muestraTiempo / 1000);
		let decimal = ("000" + muestraTiempo % 1000).slice(-3);
		let minutos = Math.floor(enteros / 60);
		let segundos = enteros % 60;
		if (minutos < 10) minutos = "0" + minutos;
		if (segundos < 10) segundos = "0" + segundos;
		if ((modo === 'o' || modo === 'g')) {
			valor = minutos + ":" + segundos;
		} else {
			if (muestraCentesimas) {
				decimal = decimal.substring(0, 2);
			} else {
				decimal = decimal.substring(0, 1) + "0";
			}
			valor = enteros + "." + decimal
		}
	}
	time.innerHTML = `${time.text1}${valor}${time.text2}`;
}
function setSpeed(miTiempo) {

	let velo = "-.--";

	if (miTiempo > 5000) {
		velo = (lengthInput.value / (miTiempo / 1000)).toFixed(1);
		if (velo > (maxSpeedInput.value * 1)) velo = "-.--";
	}

	speed.innerHTML = `${speed.text1}${velo} m/s${speed.text2}`;

}
function updateInfo() {

	eliminated.innerHTML = eliminated.text1;

	if (!general.editing) {
		if (elim === 1) {
			faults.style.visibility = "hidden";
			refusals.style.visibility = "hidden";
			eliminated.style.visibility = "visible";
		} else {
			faults.style.visibility = "visible";
			refusals.style.visibility = "visible";
			eliminated.style.visibility = "hidden";
		}
	}

}
/* ----- DRAGABLE ELEMENTS FUNTIONS ----- */
function makeDragable(element) {

	element.addEventListener("mousedown", dragStart);
	element.addEventListener("mouseup", dragEnd);
	element.addEventListener("mouseout", dragEnd);
	element.addEventListener("mousemove", drag);

	element.isDragable = true;
	element.isDragging = false;

	element.mouseX = 0;
	element.mouseY = 0;

	element.dx = 0;
	element.dy = 0;

	dragProperties(element);

}
function dragStart(e) {

	let target = e.target.isDragable
		? e.target
		: e.target.parentNode;

	if (target.isDragable && general.editing) {
		if ((!general.showing || target.id === "general") && (!modal.showing || target.id === "modal")) {
			target.mouseX = e.clientX;
			target.mouseY = e.clientY;
			target.isDragging = true;
			target.style.outline = "1px solid #FF0000FF";
			target.style.zIndex = 1000;
			target.dxOld = target.dx || 0;
			target.dyOld = target.dy || 0;
		}
	}
}
function drag(e) {

	let target = e.target.isDragable
		? e.target
		: e.target.parentNode;

	if (target.isDragging) {
		target.dx = e.clientX - target.mouseX;
		target.dy = e.clientY - target.mouseY;
		target.style.left = (target.posX + target.dx) + 'px';
		target.style.top = (target.posY + target.dy) + 'px';
	}
}
function dragEnd(e) {

	let target = e.target.isDragable
		? e.target
		: e.target.parentNode;

	if (target.isDragging) {
		target.isDragging = false;
		target.style.outline = "none";
		target.posX += target.dx;
		target.posY += target.dy;
		target.style.zIndex = target.posZ;
		if (target.dx != target.dxOld || target.dy != target.dyOld) {
			populateUndoArray(readAllSettings());
		}
	}
}
function dragProperties(e) {

	const compStyle = window.getComputedStyle(e);

	e.fontFamily = compStyle.getPropertyValue("font-family");
	e.fontSize = parseInt(compStyle.getPropertyValue("font-size"), 10);
	e.color = rgbaToHex(compStyle.getPropertyValue("color"));
	e.bgColor = rgbaToHex(compStyle.getPropertyValue("background-color"));
	e.hiddenCheck = e.hiddenCheck || false;

	e.height = parseInt(compStyle.getPropertyValue("height"), 10);
	e.width = parseInt(compStyle.getPropertyValue("width"), 10);

	e.posX = parseInt(compStyle.getPropertyValue("left"), 10);
	e.posY = parseInt(compStyle.getPropertyValue("top"), 10);
	e.posZ = parseInt(compStyle.getPropertyValue("z-index"), 10);

}
function rgbaToHex(rgba) {
	// convertir color rgba a formato hexadecimal
	const hex = rgba.match(/^(rgba|rgb)\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)$/);
	const r = parseInt(hex[2], 10).toString(16).padStart(2, '0').toUpperCase();
	const g = parseInt(hex[3], 10).toString(16).padStart(2, '0').toUpperCase();
	const b = parseInt(hex[4], 10).toString(16).padStart(2, '0').toUpperCase();
	const a = (hex[5]
		? Math.round(parseFloat(hex[5]) * 255).toString(16).padStart(2, '0')
		: "FF").toUpperCase();
	return `#${r}${g}${b}${a}`;
}

/* ----- MODAL WINDOW FUNCTIONS ----- */
function modalApply() {

	modal.elemento.style.fontFamily = fontInput.value;
	modal.elemento.style.fontSize = sizeInput.value * 1 + 'px';
	modal.elemento.style.color = textColorInput.value;
	modal.elemento.style.backgroundColor = itemBGcolorInput.value;
	modal.elemento.hiddenCheck = hiddenCheck.checked;

	modal.elemento.style.height = itemHeight.value * 1 + 'px';
	modal.elemento.style.width = itemWidth.value * 1 + 'px';

	modal.elemento.style.left = posXInput.value * 1 + 'px';
	modal.elemento.style.top = posYInput.value * 1 + 'px';

	let zMinMax = posZInput.value * 1;
	if (zMinMax > 9) zMinMax = 999;
	if (zMinMax < 1) zMinMax = 1;
	modal.elemento.posZ = zMinMax;
	modal.elemento.style.zIndex = zMinMax;

	modal.elemento.text1 = text1.value;
	modal.elemento.text2 = text2.value;

	eliminated.innerHTML = eliminated.text1;

}
function modalAccept() {
	modalApply();
	modal.elemento.text1old = text1.value;
	modal.elemento.text2old = text2.value;
	modal.style.display = "none";
	modal.showing = false;
	populateUndoArray(readAllSettings());
}
function modalCancel() {

	let modalEstado = getComputedStyle(modal);

	if (modalEstado.getPropertyValue("display") != "none") {

		modal.style.display = "none";
		modal.showing = false;

		modal.elemento.style.fontFamily = modal.elemento.fontFamily;
		modal.elemento.style.fontSize = modal.elemento.fontSize * 1 + 'px';
		modal.elemento.style.color = modal.elemento.color;
		modal.elemento.style.backgroundColor = modal.elemento.bgColor;

		modal.elemento.style.height = modal.elemento.height * 1 + 'px';
		modal.elemento.style.width = modal.elemento.width * 1 + 'px';

		modal.elemento.style.left = modal.elemento.posX * 1 + 'px';
		modal.elemento.style.top = modal.elemento.posY * 1 + 'px';
		modal.elemento.style.zIndex = modal.elemento.posZ * 1;

		modal.elemento.text1 = modal.elemento.text1old;
		modal.elemento.text2 = modal.elemento.text2old;

		eliminated.innerHTML = eliminated.text1;

	}

}

/* ----- GENERAL WINDOW FUNCTIONS ----- */
function generalApply() {
	toggleImpExp();
	croma.style.backgroundColor = cromaBGcolorInput.value;
}
function generalAccept() {
	generalApply();
	general.style.display = "none";
	general.showing = false;
	populateUndoArray(readAllSettings());
}
function generalCancel() {

	let generalEstado = getComputedStyle(general);

	if (generalEstado.getPropertyValue("display") != "none") {

		general.style.display = "none";
		general.showing = false;
		croma.style.backgroundColor = general.bgColor;
		imageName.value = general.imageName;
	}

	updateInfo();

}
function generalReset() {
	if (rUsure()) {
		localStorage.removeItem("streamSettings");
		location.reload();
	}
}
function generalEdit() {

	toggleImpExp();

	general.editing = !general.editing;

	// change cursor over dragable elements
	for (let item of dragable) {
		item.classList.toggle("move");
	}

	if (general.editing) {

		editButton.innerHTML = "Exit Edit";

		for (let item of dragable) {
			item.style.visibility = "visible";
			item.hidden = false;
		}

		general.style.display = "none";
		general.showing = false;

	} else {
		editButton.innerHTML = "Enter Edit";
		for (let item of dragable) item.hidden = item.hiddenCheck;
		updateInfo();
	}
}
function generalSave() {
	generalAccept();
	storeLocal("streamSettings", readAllSettings());
}
function readAllSettings() {

	imgData = getBase64Image(overlay);

	let mySettings = {
		visual: {

			"bgColor": cromaBGcolorInput.value,
			"length": lengthInput.value,
			"maxSpeed": maxSpeedInput.value,
			"imgName": imageName.value,
			imgData
		}
	}

	for (let item of dragable) {

		dragProperties(item);

		mySettings[item.id] = {};

		mySettings[item.id].fontFamily = item.fontFamily;
		mySettings[item.id].fontSize = item.fontSize;
		mySettings[item.id].color = item.color;
		mySettings[item.id].bgColor = item.bgColor;
		mySettings[item.id].hidden = item.hidden;
		mySettings[item.id].height = item.height;
		mySettings[item.id].width = item.width;
		mySettings[item.id].posX = item.posX;
		mySettings[item.id].posY = item.posY;
		mySettings[item.id].posZ = item.posZ;
		mySettings[item.id].text1 = item.text1;
		mySettings[item.id].text2 = item.text2;

	}
	return mySettings;
}
function generalImpExp() {
	if (defSettings) {
		JSONfile.click();
	} else {
		exportFile();
	}
}
function toggleImpExp() {
	defSettings = false;
	impExButton.innerHTML = "Export";
}
function loadImg() {
	if (imageLoaded) {
		if (rUsure()) {
			overlay.src = "";
			imageFile.value = "";
			imageName.value = "";
			imageLoaded = false;
			imageStatus.innerHTML = "No File";
			imageStatus.style.color = "red";
			loadImgButton.innerHTML = "Load";
		}
	} else {
		imageFile.click();
	}
}
function displayFileName(input) {
	if (input.files.length > 0) {
		imageName.value = input.files[0].name;
		imageLoaded = true;
		imageStatus.innerHTML = "Loaded";
		imageStatus.style.color = "green";
		loadImgButton.innerHTML = "Delete";
	}
}

/* ----- POPUP HELP WINDOW FUNCTIONS -----*/
function mInfo(id) {
	vInfo.style.display = "block";
	if (id === "visualInfoMod" || id === "visualInfoGen") {
		vInfo.innerHTML = "Temporarily apply the modifications";

	} else if (id === "acceptInfoMod" || id === "acceptInfoGen") {
		vInfo.innerHTML = "Apply the modifications and close this window";

	} else if (id === "cancelInfoMod" || id === "cancelInfoModX" || id === "cancelInfoGenX") {
		vInfo.innerHTML = "Discard the modifications and close this window";

	} else if (id === "editButton") {
		vInfo.innerHTML = "Toggle between running mode and editing mode to show hidden elements and enable editing";

	} else if (id === "saveInfo") {
		vInfo.innerHTML = "Apply the modifications and save <b>all settings</b>";

	} else if (id === "resetInfoGen") {
		vInfo.innerHTML = "Return to <b>factory settings</b> and delete saved settings";

	} else if (id === "impExButton") {
		vInfo.innerHTML = "Export current config or import previous exported. Import only available with reseted settings.";

	} else if (id === "bgColor") {
		vInfo.innerHTML = "Background color in HEX code. Last two digits 00 will make it transparent. i.e. #FFFFFF00";

	} else if (id === "length") {
		vInfo.innerHTML = "Course length to calculate speed in real time as time increases when local timer is connected.";

	} else if (id === "maxSpeed") {
		vInfo.innerHTML = "Maximun speed to be displayed in real time as time increases when local timer is connected.";

	} else {
		vInfo.style.display = "none";
	}
}
function oInfo() {
	clearTimeout(infoTimeout);
	vInfo.style.display = "none";
}
function rUsure() {
	return (confirm("This can't be undone.\n\n¿Are you sure?\n"));
}

/* ----- SETTINGS EXPORT AND IMPORT FUNCTIONS -----*/
function exportFile() {

	const actualDate = new Date();

	const YYYY = actualDate.getFullYear();
	const MM = ('0' + (actualDate.getMonth() + 1)).slice(-2);
	const DD = ('0' + actualDate.getDate()).slice(-2);
	const hh = ('0' + actualDate.getHours()).slice(-2);
	const mm = ('0' + actualDate.getMinutes()).slice(-2);
	const ss = ('0' + actualDate.getSeconds()).slice(-2);

	const contenido = JSON.stringify(readAllSettings());

	const nombreArchivo = `${YYYY}${MM}${DD}-${hh}${mm}${ss}-streaming.json`;
	const tipoArchivo = "text/json;charset=utf-8;";

	const enlaceDescarga = document.createElement("a");
	const archivoBlob = new Blob([contenido], { type: tipoArchivo });

	enlaceDescarga.href = URL.createObjectURL(archivoBlob);
	enlaceDescarga.download = nombreArchivo;
	enlaceDescarga.click();

	URL.revokeObjectURL(enlaceDescarga.href);
}
function importFile(archivo) {

	const reader = new FileReader();

	reader.onload = function (event) {
		importSettings(JSON.parse(event.target.result));
		general.style.display = "none";
		general.showing = false;
	};

	reader.readAsText(archivo);
}

/* ----- UNDO FUNCTIONS ----- */
function populateUndoArray(element) {

	if (undoPointer < undoArray.length - 1) {
		undoArray.splice(undoPointer + 1);
	}

	while (undoArray.length >= 100) {
		undoArray.shift();
	}

	undoArray.push(element);
	undoPointer = undoArray.length - 1;

}
function undoEdit() {
	if (undoArray.length > 0 && undoPointer > 0) {
		undoPointer--;
		importSettings(undoArray[undoPointer]);
	}
}
function redoEdit() {
	if (undoArray.length > 0 && undoPointer < undoArray.length - 1) {
		undoPointer++;
		importSettings(undoArray[undoPointer]);
	}
}

/* ----- CURSOR HIDE/SHOW ----- */
function hideCursor() {
	document.body.classList.add('hide-cursor');
}
function showCursor() {
	document.body.classList.remove('hide-cursor');
	clearTimeout(hideCursorTimer);
	hideCursorTimer = setTimeout(hideCursor, hideCursorDly);
}