
var docSerSta = document.getElementById('serialStatus');
var docSerLis = document.getElementById('serialList');
var docBConec = document.getElementById('bConectar');
var docBRefre = document.getElementById('bRefrescar');
var docSerBau = document.getElementById('serialBaud');

var serStatus = 0;
var serConnected = null;
var retNoPing = 60000;
var noPingTimer = setTimeout(noPing, retNoPing);
var connection = new WebSocket('ws://' + location.host + '/');

connection.onopen = () => { connection.send("0A0"); };
connection.onclose = () => {
    docSerSta.style.color = "#F00";
    docSerSta.innerHTML = "{{MOC_restart_app}}";
    docBConec.disabled = true;
    docBRefre.disabled = true;
}
connection.onmessage = function (mensaje) {

    if (mensaje.data == '__ping__') {
        clearTimeout(noPingTimer);
        noPingTimer = setTimeout(noPing, retNoPing);
        return;
    }
    console.log(mensaje.data);
    var datos = mensaje.data.split(";");
    if (datos[0] == "0A0") {

        // almacenamos ultimo puerto seleccionado
        docSerLis.old = docSerLis.value;

        // eliminar todos los puertos menos el primero
        docSerLis.length = 1;

        // añadimos resto de puertos (si existen)
        if (datos[2]) {
            const puertos = datos[2].split(',');
            puertos.forEach(puerto => {
                const opcionPuerto = document.createElement("option");
                opcionPuerto.value = puerto;
                opcionPuerto.textContent = puerto;
                docSerLis.appendChild(opcionPuerto);
            });
        }

        docSerLis.value = datos[1];

        serStatus = parseInt(datos[3]);
        switch (serStatus) {
            case 0:
                serConnected = null;
                docSerSta.style.color = "#000";
                docSerSta.innerHTML = "{{MOC_status_0}}";
                docBConec.innerHTML = "{{MOC_connect}}";
                break;
            case 1:
            case 2:
            case 3:
            case 4:
                serConnected = null;
                docSerSta.style.color = "#F00";
                docBConec.innerHTML = "{{MOC_connect}}"
                if (serStatus === 1) docSerSta.innerHTML = `{{MOC_status_1}}`;
                if (serStatus === 2) docSerSta.innerHTML = `{{MOC_status_2}}`;
                if (serStatus === 3) docSerSta.innerHTML = `{{MOC_status_3}}`;
                if (serStatus === 4) docSerSta.innerHTML = `{{MOC_status_4}}`;
                break;
            case 5:
            case 6:
            case 7:
                serConnected = datos[1];
                docBConec.innerHTML = "{{MOC_disconnect}}";
                if (serStatus === 5) {
                    docSerSta.style.color = "#555";
                    docSerSta.innerHTML = "{{MOC_status_5}}";
                } else if (serStatus === 6) {
                    docSerSta.style.color = "#8C8";
                    docSerSta.innerHTML = "{{MOC_status_6}}";
                } else if (serStatus === 7) {
                    docSerSta.style.color = "#080";
                    docSerSta.innerHTML = "{{MOC_status_7}}";
                }
                break;
        }
        docSerBau.value = datos[4];
        docBRefre.disabled = false;
        docBConec.disabled = false;
    }
}

function connectSerial() {
    if (docSerLis.selectedIndex !== 0) {
        docBConec.disabled = true;
        const serSelected = serStatus < 4
            ? docSerLis.value
            : serConnected;
        const serBauds = docSerBau.value;
        connection.send(`1A0;${(serStatus < 4) * 1};${serSelected};${serBauds}`);
    }
}
function refreshSerial() {
    docBRefre.disabled = true;
    connection.send('1A0;2');
}
function noPing() { location.reload(); }