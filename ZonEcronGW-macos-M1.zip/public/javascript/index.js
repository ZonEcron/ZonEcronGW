let connection = new WebSocket('ws://' + location.host + '/');
const info = new URLSearchParams(window.location.search).get('info') || 'manual';
const reqLang = location.pathname.split('/')[1];

if (info === 'licencia') {
    connection.onopen = function () { connection.send(`0B1;${reqLang}`); };
    connection.onmessage = function (mensaje) {
        if (mensaje.data.startsWith("0B1")) {
            document.getElementById("texto").innerHTML = mensaje.data.substring(4);
            connection.close();
        }
    }
} else {
    connection.onopen = function () { connection.send(`0B0;${reqLang}`); };
    connection.onmessage = function (mensaje) {
        if (mensaje.data.startsWith("0B0")) {
            document.getElementById("texto").innerHTML = mensaje.data.substring(4);
            connection.close();
        }
    }
}